CudaText editor

* http://uvviewsoft.com
* http://wiki.freepascal.org/CudaText

Laz 1.7 trunk, fpc 3.0.0
