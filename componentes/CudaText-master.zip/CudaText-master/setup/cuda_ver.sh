#!/bin/sh
cuda_ver=1.4.10.0
