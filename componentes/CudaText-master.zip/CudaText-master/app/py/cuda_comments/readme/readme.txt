Plugin for CudaText.
Commands to toggle comments.
Dialog to config these commands
Dialog to edit stream "brackets" (start/end strings).

Author: A.Kvichanskiy (kvichans at github.com)
