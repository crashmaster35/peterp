Plugin for CudaText
Finds and hilites (with back-color) bracket under caret and its pair bracket
(pair bracket searched considering nested brackets).
Brackets are configured per lexer in config file.

Gives items in Plugins: 
- edit config file
- jump to pair bracket
- select text to pair bracket

Author: Alexey T.
License: MIT
