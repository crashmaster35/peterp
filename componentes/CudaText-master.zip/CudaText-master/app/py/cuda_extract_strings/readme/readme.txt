plugin for CudaText.
gives command "Extract Strings"--same dialog as in SynWrite. can find by regex
all strings in current editor and then a)copy to clipb, b)copy to new tab.

Author: AlexeyT
