def HelloWorld():
	print "Hello World!"

if __name__=="__main__":
    HelloWorld()
