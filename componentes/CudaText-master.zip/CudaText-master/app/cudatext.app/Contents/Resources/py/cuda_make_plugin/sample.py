        n = ed.get_line_count()
        s = "Lines count: " + str(n)
        msg_box(s, MB_OK)
