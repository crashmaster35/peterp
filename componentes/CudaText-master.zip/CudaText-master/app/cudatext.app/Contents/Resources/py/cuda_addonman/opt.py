
ch_user = []
ch_def = [
  'https://raw.githubusercontent.com/Alexey-T/CudaText-registry/master/registry-addons.txt',
  'https://raw.githubusercontent.com/Alexey-T/CudaText-registry/master/registry-lexers.txt',
  'https://raw.githubusercontent.com/kvichans/CudaText-registry/master/registry-addons.txt',
  ]
readme = True
proxy = ''
