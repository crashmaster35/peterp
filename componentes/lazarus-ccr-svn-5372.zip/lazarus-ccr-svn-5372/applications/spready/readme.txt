spready is a relatively complex demonstration of the fpspreadsheet library
and its visual controls.
