For more information about fpsnvsync see the lazarus wiki at http://wiki.lazarus.freepascal.org/fpsvnsync.
