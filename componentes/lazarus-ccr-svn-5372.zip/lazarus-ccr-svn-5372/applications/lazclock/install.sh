#!/bin/sh
# Force Bourne shell in case tcsh is default.

mkdir /usr/share/lazclock
mkdir /usr/share/lazclock/skins
cp skins/wallclock1.PNG /usr/share/lazclock/skins/

