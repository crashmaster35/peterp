#!/bin/bash

cp ./libfmod-3.75.so /usr/lib/libfmod-3.75.so
ln /usr/lib/libfmod-3.75.so /usr/lib/libfmod.so -sf

echo "libfmod 3.75 is now installed"

