Version: rsvg-convert-2.40.15.7z  (21-04-2016)

Downloaded from: http://opensourcepack.blogspot.com/2012/06/rsvg-convert-svg-image-conversion-tool.html

Link to download found at: https://en.wikipedia.org/wiki/Librsvg

