
# hash value = 144673572
ogconst.scnooncheck='%s has no OnChecked event handler assigned'


# hash value = 198007652
ogconst.scnoongetcode='%s has no OnGetCode event handler assigned'


# hash value = 70606420
ogconst.scnoongetkey='%s has no OnGetKey event handler assigned'


# hash value = 256936516
ogconst.scnoonchangecode='%s has no OnChangeCode event handler assigned'


# hash value = 126448559
ogconst.scdeletequery='Are you sure you want to delete this item?'


# hash value = 50645509
ogconst.scinvalidstartdate='Invalid start date'


# hash value = 206359333
ogconst.scinvalidenddate='Invalid end date'


# hash value = 209699650
ogconst.scinvalidkeyormodifier='Invalid key or modifier'


# hash value = 27791925
ogconst.scinvalidexdate='Invalid expiration date'


# hash value = 22975892
ogconst.scnoongetfilename='FileName is empty and OnGetFileName is not ass'+
'igned'

