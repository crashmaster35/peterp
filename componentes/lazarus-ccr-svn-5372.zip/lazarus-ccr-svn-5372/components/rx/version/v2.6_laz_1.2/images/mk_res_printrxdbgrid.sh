rm ../rxdbgridprintgrid.res
/usr/local/share/lazarus/tools/lazres ../rxdbgridprintgrid.res TRxDBGridPrint.png
