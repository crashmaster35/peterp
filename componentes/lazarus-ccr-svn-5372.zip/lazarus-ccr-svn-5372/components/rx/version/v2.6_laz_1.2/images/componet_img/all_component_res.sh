rm tooledit.lrs
rm rxdbgrid.lrs
rm tooledit.res
rm rxdbgrid.res

/usr/local/share/lazarus/tools/lazres rxdbgrid.res rx_markerdown.png rx_markerup.png
/usr/local/share/lazarus/tools/lazres rx_lcl.res picDateEdit.png rxbtn_downarrow.png

#../../../../tools\lazres.exe tooledit.lrs picDateEdit.bmp
#../../../../tools\lazres.exe rxdbgrid.lrs rx_markerdown.xpm rx_markerup.xpm
