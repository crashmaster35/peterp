Summary
=======

TLongTimer is a descendent of TIdleTimer with all of its properties and methods EXCEPT the property Inteval.

Additional properties set the Interval to:

Daily - at a set hour
Weekly - at a set Day (e.g. Monday) and Hour
Monthly - at a set date (e.g. 5th of the month) and Hour

Demo application is included

License: LGPL

Author 'minesadorada' on the FreePascal.Org forum

Suggested uses
==============
In a TrayIcon application to do periodical reminders, updates or alarms

Version
=======
Lazarus 1.x and FPC 2.6.x

OS
==
Written with Win32 but should be cross-platform