TCalendarLite is a light-weight calendar component, a TGraphicControl
descendant which consequently is not dependent on any widgetset.
It is not a fixed-size component, as are most calendars, but will align
and resize as needed.

License: modified LGPL (with linking exception)