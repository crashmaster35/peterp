This package contains a designer to create NIB-files which can be integrated
into an iOS application.
