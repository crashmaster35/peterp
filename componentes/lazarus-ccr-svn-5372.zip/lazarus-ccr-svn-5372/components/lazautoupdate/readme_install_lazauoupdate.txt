Installing the LazAutoUpdate Package
====================================

1. LazAutoUpdate has a requirement for the Synapse package, so install it first:
/synapse/source/lib/laz_synapse.lpk

2. Then install the lazautoupdate.lpk

..and you are good to go
