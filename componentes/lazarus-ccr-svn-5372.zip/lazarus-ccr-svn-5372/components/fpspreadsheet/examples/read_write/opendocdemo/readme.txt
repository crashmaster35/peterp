This demo demonstrates how to use fpspreadsheet to read and write LibreOffice/
OpenOffice OpenDOcument .ods files.

Please run the write demo before the read demo so the required spreadsheet file
is generated.