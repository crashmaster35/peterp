This demo demonstrates how to use fpspreadsheet to read and write Excel 8.x 
(Excel 97- 2003) xls files.

Please run the write demo before the read demo so the required spreadsheet file
is generated.