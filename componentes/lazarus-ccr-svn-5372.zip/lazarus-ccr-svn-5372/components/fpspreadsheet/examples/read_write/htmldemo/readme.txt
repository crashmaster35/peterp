This demo demonstrates how to use fpspreadsheet to read and write html files which can be opened by the browser.

Please run the write demo before the read demo in order to create the required spreadsheet file.
