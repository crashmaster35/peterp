This demo shows usage of the TsWorkbookChartSource component for
creating charts from spreadsheet data. 
