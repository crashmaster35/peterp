This example demonstrates two ways of zooming in the WorksheetGrid.

In the first one (checkbox "Override file zoom factor" off), the zoom factor
read from the spreadsheet file is used for displaying the worksheet in the
grid.

In the second one (checkbox on), the file zoom factor is ignored.

The zoom factor can be changed by entering a zoom percentage in the edit box,
or by using the mouse wheel with CTRL and SHIFT keys pressed.
