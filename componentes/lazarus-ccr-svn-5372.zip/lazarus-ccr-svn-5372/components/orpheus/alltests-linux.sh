#!/bin/sh

lazbuild -d tests/TestFlexEdit/project1.lpi
lazbuild -d tests/TestLabel/project1.lpi
lazbuild -d tests/TestRLbl/project1.lpi
lazbuild -d tests/TestSimpField/project1.lpi
lazbuild -d tests/TestSpinner/project1.lpi
lazbuild -d tests/TestTable/project1.lpi
lazbuild -d tests/TestTblEdits/project1.lpi
lazbuild -d tests/TestURL/project1.lpi
lazbuild -d tests/TestVLB/project1.lpi
lazbuild -d tests/TestCalendar/project1.lpi
