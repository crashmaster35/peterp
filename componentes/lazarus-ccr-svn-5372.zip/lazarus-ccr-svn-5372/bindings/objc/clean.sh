rm *.o
rm *.ppu
rm *.bak