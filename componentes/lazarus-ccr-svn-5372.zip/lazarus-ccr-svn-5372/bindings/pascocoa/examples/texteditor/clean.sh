rm *.bak
rm *.ppu
rm *.o
rm *.compiled