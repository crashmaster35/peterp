./objcparser /System/Library/Frameworks/AppKit.framework/Headers/NSButton.h > NSButton.inc
