Package information for aarre repository.
