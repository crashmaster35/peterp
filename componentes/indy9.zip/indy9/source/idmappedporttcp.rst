
# hash value = 167911673
idmappedporttcp.rsemptyhost='Host is empty'


# hash value = 235558265
idmappedporttcp.rspop3proxygreeting='POP3 proxy ready'


# hash value = 161658404
idmappedporttcp.rspop3unknowncommand='command must be either USER or QUIT'+


# hash value = 37901638
idmappedporttcp.rspop3quitmsg='POP3 proxy signing off'

