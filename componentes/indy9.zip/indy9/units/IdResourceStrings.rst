
# hash value = 193954862
idresourcestrings.rsalreadyconnected='Already connected.'


# hash value = 229397998
idresourcestrings.rsbyteindexoutofbounds='Byte index out of range.'


# hash value = 200455070
idresourcestrings.rscannotallocatesocket='Cannot allocate socket.'


# hash value = 35093726
idresourcestrings.rsconnectionclosedgracefully='Connection Closed Gracefu'+
'lly.'


# hash value = 236449806
idresourcestrings.rscouldnotbindsocket='Could not bind socket. Address an'+
'd port are already in use.'


# hash value = 170998846
idresourcestrings.rsfailedtimezoneinfo='Failed attempting to retrieve tim'+
'e zone information.'


# hash value = 246063870
idresourcestrings.rsnobindingsspecified='No bindings specified.'


# hash value = 157460590
idresourcestrings.rsonexecutenotassigned='OnExecute not assigned.'


# hash value = 241821662
idresourcestrings.rsnotallbytessent='Not all bytes sent.'


# hash value = 238462110
idresourcestrings.rsnotenoughdatainbuffer='Not enough data in buffer.'


# hash value = 36928270
idresourcestrings.rspackagesizetoobig='Package Size Too Big.'


# hash value = 263794190
idresourcestrings.rsrawreceiveerror0='Raw Receive Error = 0.'


# hash value = 267460766
idresourcestrings.rsicmpreceiveerror0='ICMP Receive Error = 0.'


# hash value = 19880270
idresourcestrings.rswinsockinitializationerror='Winsock Initialization Er'+
'ror.'


# hash value = 60759502
idresourcestrings.rscouldnotload='%s could not be loaded.'


# hash value = 253788718
idresourcestrings.rssetsizeexceeded='Set Size Exceeded.'


# hash value = 94647966
idresourcestrings.rsthreadclassnotspecified='Thread Class Not Specified.'


# hash value = 121326884
idresourcestrings.rsfilenotfound='File "%s" not found'


# hash value = 245409342
idresourcestrings.rsonlyoneantifreeze='Only one TIdAntiFreeze can exist p'+
'er application.'


# hash value = 74124500
idresourcestrings.rsinterceptcircularlink='%d: Circular links are not all'+
'owed'


# hash value = 258790958
idresourcestrings.rsinterceptpropisnil='InterceptEnabled cannot be set to'+
' true when Intercept is nil.'


# hash value = 217113412
idresourcestrings.rsiohandlerpropinvalid='IOHandler value is not valid'


# hash value = 36561060
idresourcestrings.rsnotconnected='Not Connected'


# hash value = 67359086
idresourcestrings.rsobjecttypenotsupported='Object type not supported.'


# hash value = 105083566
idresourcestrings.rsacceptwaitcannotbemodifiedwhileserverisactive='Accept'+
'Wait property cannot be modified while server is active.'


# hash value = 74330420
idresourcestrings.rsterminatethreadtimeout='Terminate Thread Timeout'


# hash value = 258027566
idresourcestrings.rsnoexecutespecified='No execute handler found.'


# hash value = 200790462
idresourcestrings.rsidnodatatoread='No data to read.'


# hash value = 16578265
idresourcestrings.rscannotbindrange='Can not bind in port range (%d - %d)'+


# hash value = 205797641
idresourcestrings.rsinvalidportrange='Invalid Port Range (%d - %d)'


# hash value = 260624532
idresourcestrings.rsreadtimeout='Read Timeout'


# hash value = 15506814
idresourcestrings.rsreadlnmaxlinelengthexceeded='Max line length exceeded'+
'.'


# hash value = 263797150
idresourcestrings.rsudpreceiveerror0='UDP Receive Error = 0.'


# hash value = 84895934
idresourcestrings.rsnocommandhandlerfound='No command handler found.'


# hash value = 133717294
idresourcestrings.rscannotperformtaskwhileserverisactive='Cannot perform '+
'task while server is active.'


# hash value = 209091843
idresourcestrings.rsemailsymboloutsideaddress='@ Outside address'


# hash value = 212054434
idresourcestrings.rszlcompressorinitializefailure='Unable to initialize c'+
'ompressor'


# hash value = 146441986
idresourcestrings.rszldecompressorinitializefailure='Unable to initialize'+
' decompressor'


# hash value = 149710162
idresourcestrings.rszlcompressionerror='Compression error'


# hash value = 35415314
idresourcestrings.rszldecompressionerror='Decompression error'


# hash value = 176687987
idresourcestrings.rsws2callerror='Error on call Winsock2 library function'+
' %s'


# hash value = 259317913
idresourcestrings.rsws2loaderror='Error on loading Winsock2 library (%s)'


# hash value = 136441065
idresourcestrings.rsmimeextensionempty='Extension is empty'


# hash value = 154808697
idresourcestrings.rsmimemimetypeempty='Mimetype is empty'


# hash value = 142671267
idresourcestrings.rsmimemimeextalreadyexists='Extension already exits'


# hash value = 220929779
idresourcestrings.rsregindyclients='Indy Clients'


# hash value = 214792131
idresourcestrings.rsregindyservers='Indy Servers'


# hash value = 121467475
idresourcestrings.rsregindyintercepts='Indy Intercepts'


# hash value = 79655875
idresourcestrings.rsregindyiohandlers='Indy I/O Handlers'


# hash value = 196440275
idresourcestrings.rsregindymisc='Indy Misc'


# hash value = 148377390
idresourcestrings.rsstatusresolving='Resolving hostname %s.'


# hash value = 206671246
idresourcestrings.rsstatusconnecting='Connecting to %s.'


# hash value = 79564094
idresourcestrings.rsstatusconnected='Connected.'


# hash value = 187737454
idresourcestrings.rsstatusdisconnecting='Disconnecting.'


# hash value = 263392638
idresourcestrings.rsstatusdisconnected='Disconnected.'


# hash value = 707
idresourcestrings.rsstatustext='%s'


# hash value = 94933230
idresourcestrings.rsconnecttimeout='Connect timed out.'


# hash value = 148764212
idresourcestrings.rsmsgclientencodingtext='Encoding text'


# hash value = 256109364
idresourcestrings.rsmsgclientencodingattachment='Encoding attachment'


# hash value = 154709598
idresourcestrings.rsmsgclientunkownmessageparttype='Unknown Message Part '+
'Type.'


# hash value = 116646275
idresourcestrings.rsmsgclientinvalidencoding='Invalid Encoding. UU only a'+
'llows Body and Attachments'


# hash value = 262253742
idresourcestrings.rsnntpconnectionrefused='Connection explicitly refused '+
'by NNTP server.'


# hash value = 60419649
idresourcestrings.rsnntpstringlistnotinitialized='Stringlist not initiali'+
'zed!'


# hash value = 69926046
idresourcestrings.rsnntpnoonnewsgrouplist='No OnNewsgroupList event has b'+
'een defined.'


# hash value = 244886798
idresourcestrings.rsnntpnoonnewgroupslist='No OnNewGroupsList event has b'+
'een defined.'


# hash value = 161597774
idresourcestrings.rsnntpnoonnewnewslist='No OnNewNewsList event has been '+
'defined.'


# hash value = 79564094
idresourcestrings.rslogconnected='Connected.'


# hash value = 263392638
idresourcestrings.rslogdisconnected='Disconnected.'


# hash value = 4236286
idresourcestrings.rslogeol='<EOL>'


# hash value = 264286
idresourcestrings.rslogcr='<CR>'


# hash value = 266398
idresourcestrings.rsloglf='<LF>'


# hash value = 5814912
idresourcestrings.rslogrecv='Recv '


# hash value = 5883232
idresourcestrings.rslogsent='Sent '


# hash value = 5941344
idresourcestrings.rslogstat='Stat '


# hash value = 55891876
idresourcestrings.rshttpchunkstarted='Chunk Started'


# hash value = 106627349
idresourcestrings.rshttpcontinue='Continue'


# hash value = 1858675
idresourcestrings.rshttpswitchingprotocols='Switching protocols'


# hash value = 1339
idresourcestrings.rshttpok='OK'


# hash value = 176917236
idresourcestrings.rshttpcreated='Created'


# hash value = 161251012
idresourcestrings.rshttpaccepted='Accepted'


# hash value = 138519614
idresourcestrings.rshttpnonauthoritativeinformation='Non-authoritative In'+
'formation'


# hash value = 174127892
idresourcestrings.rshttpnocontent='No Content'


# hash value = 44854852
idresourcestrings.rshttpresetcontent='Reset Content'


# hash value = 34243732
idresourcestrings.rshttppartialcontent='Partial Content'


# hash value = 38469817
idresourcestrings.rshttpmovedpermanently='Moved Permanently'


# hash value = 8808665
idresourcestrings.rshttpmovedtemporarily='Moved Temporarily'


# hash value = 123139954
idresourcestrings.rshttpseeother='See Other'


# hash value = 16362228
idresourcestrings.rshttpnotmodified='Not Modified'


# hash value = 123202153
idresourcestrings.rshttpuseproxy='Use Proxy'


# hash value = 142658292
idresourcestrings.rshttpbadrequest='Bad Request'


# hash value = 212704276
idresourcestrings.rshttpunauthorized='Unauthorized'


# hash value = 143648734
idresourcestrings.rshttpforbidden='Forbidden'


# hash value = 105725732
idresourcestrings.rshttpnotfound='Not Found'


# hash value = 89957508
idresourcestrings.rshttpmethodenotallowed='Method not allowed'


# hash value = 169739749
idresourcestrings.rshttpnotacceptable='Not Acceptable'


# hash value = 122398884
idresourcestrings.rshttpproxyauthenticationrequired='Proxy Authentication'+
' Required'


# hash value = 39802964
idresourcestrings.rshttprequesttimeout='Request Timeout'


# hash value = 105720580
idresourcestrings.rshttpconflict='Conflict'


# hash value = 321093
idresourcestrings.rshttpgone='Gone'


# hash value = 140705780
idresourcestrings.rshttplengthrequired='Length Required'


# hash value = 172402340
idresourcestrings.rshttppreconditionfailed='Precondition Failed'


# hash value = 90998615
idresourcestrings.rshttprequestentitytolong='Request Entity To Long'


# hash value = 169826808
idresourcestrings.rshttprequesturitoolong='Request-URI Too Long. 256 Char'+
's max'


# hash value = 136591301
idresourcestrings.rshttpunsupportedmediatype='Unsupported Media Type'


# hash value = 186192914
idresourcestrings.rshttpinternalservererror='Internal Server Error'


# hash value = 241979124
idresourcestrings.rshttpnotimplemented='Not Implemented'


# hash value = 230865865
idresourcestrings.rshttpbadgateway='Bad Gateway'


# hash value = 158466085
idresourcestrings.rshttpserviceunavailable='Service Unavailable'


# hash value = 5144628
idresourcestrings.rshttpgatewaytimeout='Gateway timeout'


# hash value = 35576052
idresourcestrings.rshttphttpversionnotsupported='HTTP version not support'+
'ed'


# hash value = 65646581
idresourcestrings.rshttpunknownresponsecode='Unknown Response Code'


# hash value = 251641918
idresourcestrings.rshttpheaderalreadywritten='Header has already been wri'+
'tten.'


# hash value = 156892766
idresourcestrings.rshttperrorparsingcommand='Error in parsing command.'


# hash value = 194465806
idresourcestrings.rshttpunsupportedauthorisationscheme='Unsupported autho'+
'rization scheme.'


# hash value = 240772558
idresourcestrings.rshttpcannotswitchsessionstatewhenactive='Cannot change'+
' session state when the server is active.'


# hash value = 188152414
idresourcestrings.rshttpauthalreadyregistered='This authentication method'+
' is already registered with class name %s.'


# hash value = 23236654
idresourcestrings.rshttpauthinvalidhash='Unsupported hash algorithm. This'+
' implementation supports only MD5 encoding.'


# hash value = 42843516
idresourcestrings.rshttpsspisuccess='Successfull API call'


# hash value = 185236292
idresourcestrings.rshttpsspinotenoughmem='Not enough memory is available '+
'to complete this request'


# hash value = 232235764
idresourcestrings.rshttpsspiinvalidhandle='The handle specified is invali'+
'd'


# hash value = 139843172
idresourcestrings.rshttpsspifuncnotsupported='The function requested is n'+
'ot supported'


# hash value = 185743269
idresourcestrings.rshttpsspiunknowntarget='The specified target is unknow'+
'n or unreachable'


# hash value = 202046164
idresourcestrings.rshttpsspiinternalerror='The Local Security Authority c'+
'annot be contacted'


# hash value = 185293236
idresourcestrings.rshttpsspisecpackagenotfound='The requested security pa'+
'ckage does not exist'


# hash value = 112107795
idresourcestrings.rshttpsspinotowner='The caller is not the owner of the '+
'desired credentials'


# hash value = 199769796
idresourcestrings.rshttpsspipackagecannotbeinstalled='The security packag'+
'e failed to initialize, and cannot be installed'


# hash value = 52400628
idresourcestrings.rshttpsspiinvalidtoken='The token supplied to the funct'+
'ion is invalid'


# hash value = 227300756
idresourcestrings.rshttpsspicannotpack='The security package is not able '+
'to marshall the logon buffer, so the logon attempt has failed'


# hash value = 148942117
idresourcestrings.rshttpsspiqopnotsupported='The per-message Quality of P'+
'rotection is not supported by the security package'


# hash value = 99666052
idresourcestrings.rshttpsspinoimpersonation='The security context does no'+
't allow impersonation of the client'


# hash value = 233821284
idresourcestrings.rshttpsspilogindenied='The logon attempt failed'


# hash value = 220059300
idresourcestrings.rshttpsspiunknowncredentials='The credentials supplied '+
'to the package were not recognized'


# hash value = 217116437
idresourcestrings.rshttpsspinocredentials='No credentials are available i'+
'n the security package'


# hash value = 177588324
idresourcestrings.rshttpsspimessagealtered='The message or signature supp'+
'lied for verification has been altered'


# hash value = 97241173
idresourcestrings.rshttpsspioutofsequence='The message supplied for verif'+
'ication is out of sequence'


# hash value = 92539278
idresourcestrings.rshttpsspinoauthauthority='No authority could be contac'+
'ted for authentication.'


# hash value = 29293844
idresourcestrings.rshttpsspicontinueneeded='The function completed succes'+
'sfully, but must be called again to complete the context'


# hash value = 252204436
idresourcestrings.rshttpsspicompleteneeded='The function completed succes'+
'sfully, but CompleteToken must be called'


# hash value = 155916324
idresourcestrings.rshttpsspicompletecontinueneeded='The function complete'+
'd successfully, but both CompleteToken and this function must be called '+
'to complete the context'


# hash value = 116005230
idresourcestrings.rshttpsspilocallogin='The logon was completed, but no n'+
'etwork authority was available. The logon was made using locally known i'+
'nformation'


# hash value = 185293236
idresourcestrings.rshttpsspibadpackageid='The requested security package '+
'does not exist'


# hash value = 217280910
idresourcestrings.rshttpsspicontextexpired='The context has expired and c'+
'an no longer be used.'


# hash value = 173562894
idresourcestrings.rshttpsspiincompletemessage='The supplied message is in'+
'complete.  The signature was not verified.'


# hash value = 145941790
idresourcestrings.rshttpsspiincompletecredentialnotinit='The credentials '+
'supplied were not complete, and could not be verified. The context could'+
' not be initialized.'


# hash value = 32532622
idresourcestrings.rshttpsspibuffertoosmall='The buffers supplied to a fun'+
'ction was too small.'


# hash value = 182147070
idresourcestrings.rshttpsspiincompletecredentialsinit='The credentials su'+
'pplied were not complete, and could not be verified. Additional informat'+
'ion can be returned from the context.'


# hash value = 134029998
idresourcestrings.rshttpsspirengotiate='The context data must be renegoti'+
'ated with the peer.'


# hash value = 202745198
idresourcestrings.rshttpsspiwrongprincipal='The target principal name is '+
'incorrect.'


# hash value = 22775742
idresourcestrings.rshttpsspinolsacode='There is no LSA mode context assoc'+
'iated with this context.'


# hash value = 174529086
idresourcestrings.rshttpsspitimescew='The clocks on the client and server'+
' machines are skewed.'


# hash value = 67269630
idresourcestrings.rshttpsspiuntrustedroot='The certificate chain was issu'+
'ed by an untrusted authority.'


# hash value = 167477166
idresourcestrings.rshttpsspiillegalmessage='The message received was unex'+
'pected or badly formatted.'


# hash value = 151145598
idresourcestrings.rshttpsspicertunknown='An unknown error occurred while '+
'processing the certificate.'


# hash value = 10124974
idresourcestrings.rshttpsspicertexpired='The received certificate has exp'+
'ired.'


# hash value = 234815614
idresourcestrings.rshttpsspiencryptionfailure='The specified data could n'+
'ot be encrypted.'


# hash value = 234827646
idresourcestrings.rshttpsspidecryptionfailure='The specified data could n'+
'ot be decrypted.'


# hash value = 102905246
idresourcestrings.rshttpsspialgorithmmismatch='The client and server cann'+
'ot communicate, because they do not possess a common algorithm.'


# hash value = 123656382
idresourcestrings.rshttpsspisecurityqosfailure='The security context coul'+
'd not be established due to a failure in the requested quality of servic'+
'e (e.g. mutual authentication or delegation).'


# hash value = 205443058
idresourcestrings.rshttpsspiunknwonerror='Unknown error'


# hash value = 215332947
idresourcestrings.rshttpsspierrormsg='SSPI %s returns error #%d(0x%x): %s'+


# hash value = 108090217
idresourcestrings.rshttpsspiinterfaceinitfailed='SSPI interface has faile'+
'd to initialise properly'


# hash value = 28769188
idresourcestrings.rshttpsspinopkginfospecified='No PSecPkgInfo specified'


# hash value = 164209476
idresourcestrings.rshttpsspinocredentialhandle='No credential handle acqu'+
'ired'


# hash value = 49511236
idresourcestrings.rshttpsspicannotchangecredentials='Can not change crede'+
'ntials after handle aquired. Use Release first'


# hash value = 185409205
idresourcestrings.rshttpsspiunknwoncredentialuse='Unknown credentials use'+


# hash value = 137624580
idresourcestrings.rshttpsspidoauquirecredentialhandle='Do AcquireCredenti'+
'alsHandle first'


# hash value = 26500788
idresourcestrings.rshttpsspicompletetokennotsupported='CompleteAuthToken '+
'is not supported'


# hash value = 103608011
idresourcestrings.rsblockincorrectlength='Incorrect length in received bl'+
'ock'


# hash value = 206722702
idresourcestrings.rsftpunknownhost='Unknown'


# hash value = 134236132
idresourcestrings.rsinvalidftplistingformat='Unknown FTP listing format'


# hash value = 235028180
idresourcestrings.rsftpstatusready='Connection established'


# hash value = 73794882
idresourcestrings.rsftpstatusstarttransfer='Starting FTP transfer'


# hash value = 231924341
idresourcestrings.rsftpstatusdonetransfer='Transfer complete'


# hash value = 36693588
idresourcestrings.rsftpstatusaborttransfer='Transfer aborted'


# hash value = 65639182
idresourcestrings.rscorruptservicesfile='%s is corrupt.'


# hash value = 161873086
idresourcestrings.rsinvalidservicename='%s is not a valid service.'


# hash value = 18784259
idresourcestrings.rsstackerror='Socket Error # %d'#13#10'%s'


# hash value = 181649342
idresourcestrings.rsstackinvalidip='%s is not a valid IP address.'


# hash value = 68939694
idresourcestrings.rsstackeintr='Interrupted system call.'


# hash value = 59714654
idresourcestrings.rsstackebadf='Bad file number.'


# hash value = 54024830
idresourcestrings.rsstackeacces='Access denied.'


# hash value = 239053870
idresourcestrings.rsstackefault='Bad address.'


# hash value = 203788654
idresourcestrings.rsstackeinval='Invalid argument.'


# hash value = 189756862
idresourcestrings.rsstackemfile='Too many open files.'


# hash value = 264763536
idresourcestrings.rsstackewouldblock='Operation would block. '


# hash value = 128410782
idresourcestrings.rsstackeinprogress='Operation now in progress.'


# hash value = 252119326
idresourcestrings.rsstackealready='Operation already in progress.'


# hash value = 261589214
idresourcestrings.rsstackenotsock='Socket operation on non-socket.'


# hash value = 75513566
idresourcestrings.rsstackedestaddrreq='Destination address required.'


# hash value = 116913486
idresourcestrings.rsstackemsgsize='Message too long.'


# hash value = 164857582
idresourcestrings.rsstackeprototype='Protocol wrong type for socket.'


# hash value = 138799006
idresourcestrings.rsstackenoprotoopt='Bad protocol option.'


# hash value = 115111198
idresourcestrings.rsstackeprotonosupport='Protocol not supported.'


# hash value = 11121038
idresourcestrings.rsstackesocktnosupport='Socket type not supported.'


# hash value = 42079966
idresourcestrings.rsstackeopnotsupp='Operation not supported on socket.'


# hash value = 267040158
idresourcestrings.rsstackepfnosupport='Protocol family not supported.'


# hash value = 242836446
idresourcestrings.rsstackeafnosupport='Address family not supported by pr'+
'otocol family.'


# hash value = 206749614
idresourcestrings.rsstackeaddrinuse='Address already in use.'


# hash value = 123963166
idresourcestrings.rsstackeaddrnotavail='Cannot assign requested address.'


# hash value = 185137086
idresourcestrings.rsstackenetdown='Network is down.'


# hash value = 144425662
idresourcestrings.rsstackenetunreach='Network is unreachable.'


# hash value = 110463054
idresourcestrings.rsstackenetreset='Net dropped connection or reset.'


# hash value = 10538942
idresourcestrings.rsstackeconnaborted='Software caused connection abort.'


# hash value = 122394302
idresourcestrings.rsstackeconnreset='Connection reset by peer.'


# hash value = 209658350
idresourcestrings.rsstackenobufs='No buffer space available.'


# hash value = 147617726
idresourcestrings.rsstackeisconn='Socket is already connected.'


# hash value = 17421710
idresourcestrings.rsstackenotconn='Socket is not connected.'


# hash value = 15751278
idresourcestrings.rsstackeshutdown='Cannot send or receive after socket i'+
's closed.'


# hash value = 234235694
idresourcestrings.rsstacketoomanyrefs='Too many references, cannot splice'+
'.'


# hash value = 170605822
idresourcestrings.rsstacketimedout='Connection timed out.'


# hash value = 192796430
idresourcestrings.rsstackeconnrefused='Connection refused.'


# hash value = 35490110
idresourcestrings.rsstackeloop='Too many levels of symbolic links.'


# hash value = 174615294
idresourcestrings.rsstackenametoolong='File name too long.'


# hash value = 167840590
idresourcestrings.rsstackehostdown='Host is down.'


# hash value = 133302830
idresourcestrings.rsstackehostunreach='No route to host.'


# hash value = 200910889
idresourcestrings.rsstackenotempty='Directory not empty'


# hash value = 119312446
idresourcestrings.rsstackeproclim='Too many processes.'


# hash value = 112916366
idresourcestrings.rsstackeusers='Too many users.'


# hash value = 260422558
idresourcestrings.rsstackedquot='Disk Quota Exceeded.'


# hash value = 182064334
idresourcestrings.rsstackestale='Stale NFS file handle.'


# hash value = 146532926
idresourcestrings.rsstackeremote='Too many levels of remote in path.'


# hash value = 71567182
idresourcestrings.rsstacksysnotready='Network subsystem is unavailable.'


# hash value = 72557294
idresourcestrings.rsstackvernotsupported='WINSOCK DLL Version out of rang'+
'e.'


# hash value = 148232462
idresourcestrings.rsstacknotinitialised='Winsock not loaded yet.'


# hash value = 212974958
idresourcestrings.rsstackhost_not_found='Host not found.'


# hash value = 93453502
idresourcestrings.rsstacktry_again='Non-authoritative response (try again'+
' or check DNS setup).'


# hash value = 198336510
idresourcestrings.rsstackno_recovery='Non-recoverable errors: FORMERR, RE'+
'FUSED, NOTIMP.'


# hash value = 167242078
idresourcestrings.rsstackno_data='Valid name, no data record (check DNS s'+
'etup).'


# hash value = 4348452
idresourcestrings.rscmdnotrecognized='command not recognized'


# hash value = 48511298
idresourcestrings.rsgophernotgopherplus='%s is not a Gopher+ server'


# hash value = 186051378
idresourcestrings.rscodenoerror='RCode NO Error'


# hash value = 197019138
idresourcestrings.rscodequeryformat='DNS Server Reports Query Format Erro'+
'r'


# hash value = 150227778
idresourcestrings.rscodequeryserver='DNS Server Reports Query Server Erro'+
'r'


# hash value = 161676562
idresourcestrings.rscodequeryname='DNS Server Reports Query Name Error'


# hash value = 215376338
idresourcestrings.rscodequerynotimplemented='DNS Server Reports Query Not'+
' Implemented Error'


# hash value = 213237778
idresourcestrings.rscodequeryqueryrefused='DNS Server Reports Query Refus'+
'ed Error'


# hash value = 213278562
idresourcestrings.rscodequeryunknownerror='Server Returned Unknown Error'


# hash value = 3904372
idresourcestrings.rsdnstimeout='TimedOut'


# hash value = 112001598
idresourcestrings.rsdnsmfisobsolete='MF is an Obsolete Command. USE MX.'


# hash value = 5025854
idresourcestrings.rsdnsmdisobsolete='MD is an Obsolete Command. Use MX.'


# hash value = 85444366
idresourcestrings.rsdnsmailaobsolete='MailA is an Obsolete Command. USE M'+
'X.'


# hash value = 86333508
idresourcestrings.rsdnsmailbnotimplemented='-Err 501 MailB is not impleme'+
'nted'


# hash value = 90617428
idresourcestrings.rsqueryinvalidquerycount='Invalid Query Count %d'


# hash value = 131847236
idresourcestrings.rsqueryinvalidpacketsize='Invalid Packet Size %d'


# hash value = 19482100
idresourcestrings.rsquerylessthanfour='Received Packet is too small. Less'+
' than 4 bytes %d'


# hash value = 90976788
idresourcestrings.rsqueryinvalidheaderid='Invalid Header Id %d'


# hash value = 150933028
idresourcestrings.rsquerylessthantwelve='Received Packet is too small. Le'+
'ss than 12 bytes %d'


# hash value = 186846420
idresourcestrings.rsquerypackreceivedtoosmall='Received Packet is too sma'+
'll. %d'


# hash value = 188094675
idresourcestrings.rslpddatafilesaved='Data file saved to %s'


# hash value = 203064147
idresourcestrings.rslpdcontrolfilesaved='Control file save to %s'


# hash value = 4132996
idresourcestrings.rslpddirectorydoesnotexist='Directory %s does not exist'+


# hash value = 128180800
idresourcestrings.rslpdserverstarttitle='Winshoes LPD Server %s '


# hash value = 87918693
idresourcestrings.rslpdserveractive='Server status: active'


# hash value = 254664499
idresourcestrings.rslpdqueuestatus='Queue %s status: %s'


# hash value = 109887502
idresourcestrings.rslpdclosingconnection='closing connection'


# hash value = 245543011
idresourcestrings.rslpdunknownqueue='Unknown queue %s'


# hash value = 130707955
idresourcestrings.rslpdconnectto='connected with %s'


# hash value = 110500034
idresourcestrings.rslpdabortjob='abort job'


# hash value = 150773413
idresourcestrings.rslpdreceivecontrolfile='Receive control file'


# hash value = 178855269
idresourcestrings.rslpdreceivedatafile='Receive data file'


# hash value = 164216836
idresourcestrings.rslpdnoqueuesdefined='Error: no queues defined'


# hash value = 184796820
idresourcestrings.rstimeout='Timeout'


# hash value = 151365732
idresourcestrings.rstftpunexpectedop='Unexpected operation from %s:%d'


# hash value = 97345794
idresourcestrings.rstftpunsupportedtrxmode='Unsupported transfer mode: "%'+
's"'


# hash value = 111237187
idresourcestrings.rstftpdiskfull='Unable to complete write request, progr'+
'ess halted at %d bytes'


# hash value = 71431619
idresourcestrings.rstftpfilenotfound='Unable to open %s'


# hash value = 115649012
idresourcestrings.rstftpaccessdenied='Access to %s denied'


# hash value = 159713265
idresourcestrings.rstidtextinvalidcount='Invalid Text count. TIdText must'+
' be greater than 1'


# hash value = 42583088
idresourcestrings.rstidmessagepartcreate='TIdMessagePart can not be creat'+
'ed.  Use descendant classes. '


# hash value = 65692958
idresourcestrings.rstidmessageerrorsavingattachment='Error saving attachm'+
'ent.'


# hash value = 251246500
idresourcestrings.rspop3fieldnotspecified=' not specified'


# hash value = 112545874
idresourcestrings.rspop3unrecognizedpop3responseheader='Unrecognized POP3'+
' Response Header:'#10'"%s"'


# hash value = 29785849
idresourcestrings.rspop3serverdonotsupportapop='Server do not support APO'+
'P (no timestamp)'


# hash value = 197632638
idresourcestrings.rsimap4connectionstateerror='Unable to execute command,'+
' wrong connection state;Current connection state: %s.'


# hash value = 198229886
idresourcestrings.rsunrecognizedimap4responseheader='Unrecognized IMAP4 R'+
'esponse Header.'


# hash value = 18521
idresourcestrings.rsimap4connectionstateany='Any'


# hash value = 40240804
idresourcestrings.rsimap4connectionstatenonauthenticated='Non Authenticat'+
'ed'


# hash value = 36923044
idresourcestrings.rsimap4connectionstateauthenticated='Authenticated'


# hash value = 204189476
idresourcestrings.rsimap4connectionstateselected='Selected'


# hash value = 155447552
idresourcestrings.rstelnetsrvusernameprompt='Username: '


# hash value = 182710112
idresourcestrings.rstelnetsrvpasswordprompt='Password: '


# hash value = 50198126
idresourcestrings.rstelnetsrvinvalidlogin='Invalid Login.'


# hash value = 155603774
idresourcestrings.rstelnetsrvmaxloginattempt='Allowed login attempts exce'+
'eded, good bye.'


# hash value = 72350846
idresourcestrings.rstelnetsrvnoauthhandler='No authentication handler has'+
' been specified.'


# hash value = 173763570
idresourcestrings.rstelnetsrvwelcomestring='Indy Telnet Server'


# hash value = 82629502
idresourcestrings.rstelnetsrvondataavailableisnil='OnDataAvailable event '+
'is nil.'


# hash value = 185558135
idresourcestrings.rstelnetcliconnecterror='server not responding'


# hash value = 131097934
idresourcestrings.rstelnetclireaderror='Server did not respond.'


# hash value = 60458686
idresourcestrings.rsnetcalinvalidipstring='The string %s does not transla'+
'te into a valid IP.'


# hash value = 87689502
idresourcestrings.rsnetcalcinvalidnetworkmask='Invalid network mask.'


# hash value = 178936766
idresourcestrings.rsnetcalcinvalidvaluelength='Invalid value length: Shou'+
'ld be 32.'


# hash value = 167814574
idresourcestrings.rsnetcalconfirmlongiplist='There is too many IP address'+
'es in the specified range (%d) to be displayed at design time.'


# hash value = 3551924
idresourcestrings.rsidentreplytimeout='Reply Timed Out:  The server did n'+
'ot return a response and the query has been abandoned'


# hash value = 66440804
idresourcestrings.rsidentinvalidport='Invalid Port:  The foreign or local'+
' port is not specified correctly or invalid'


# hash value = 85719186
idresourcestrings.rsidentnouser='No User:  Port pair is not used or not u'+
'sed by an identifiable user'


# hash value = 1683380
idresourcestrings.rsidenthiddenuser='Hidden User:  Information was not re'+
'turned at a user'#39's request'


# hash value = 19794030
idresourcestrings.rsidentunknownerror='Unknown or other error: Can not de'+
'termine owner, other error, or the error can not be revealed.'


# hash value = 4691652
idresourcestrings.rsaaboutformcaption='About'


# hash value = 89600569
idresourcestrings.rsaaboutboxcompname='Internet Direct (Indy)'


# hash value = 263135358
idresourcestrings.rsaaboutmenuitemname='About Internet &Direct (Indy) %s.'+
'..'


# hash value = 167890515
idresourcestrings.rsaaboutboxversion='Version %s'


# hash value = 5120567
idresourcestrings.rsaaboutboxcopyright='Copyright (c) 1993 - 2003'#13#10'K'+
'udzu (Chad Z. Hower)'#13#10'and the'#13#10'Indy Pit Crew'


# hash value = 36384250
idresourcestrings.rsaaboutboxpleasevisit='For the latest updates and info'+
'rmation please visit:'


# hash value = 28334351
idresourcestrings.rsaaboutboxindywebsite='http://www.nevrona.com/indy/'


# hash value = 186968082
idresourcestrings.rsaaboutcreditscoordinator='Project Coordinator'


# hash value = 140760034
idresourcestrings.rsaaboutcreditscocordinator='Project Co-Coordinator'


# hash value = 72925570
idresourcestrings.rsaaboutcreditsdocumentation='Documentation Coordinator'+


# hash value = 10642
idresourcestrings.rsaaboutcreditsdemos='Demos Coordinator'


# hash value = 27453954
idresourcestrings.rsaaboutcreditsdistribution='Distribution Coordinator'


# hash value = 79007635
idresourcestrings.rsaaboutcreditsretiredpast='Retired/Past Contributors'


# hash value = 1339
idresourcestrings.rsaaboutok='OK'


# hash value = 82971490
idresourcestrings.rsbindingformcaption='Binding Editor'


# hash value = 173988
idresourcestrings.rsbindingaddcaption='&Add'


# hash value = 193742565
idresourcestrings.rsbindingremovecaption='&Remove'


# hash value = 4910707
idresourcestrings.rsbindinglabelbindings='&Bindings'


# hash value = 125923043
idresourcestrings.rsbindinghostnamelabel='&IP Address'


# hash value = 2848404
idresourcestrings.rsbindingportlabel='&Port'


# hash value = 1339
idresourcestrings.rsbindingokbutton='OK'


# hash value = 77089212
idresourcestrings.rsbindingcancel='Cancel'


# hash value = 18476
idresourcestrings.rsbindingall='All'


# hash value = 18521
idresourcestrings.rsbindingany='Any'


# hash value = 5819229
idresourcestrings.rstunnelgetbyterange='Call to %s.GetByte [property Byte'+
's] with index <> [0..%d]'


# hash value = 222726868
idresourcestrings.rstunneltransformerrorbs='Error in transformation befor'+
'e send'


# hash value = 56439492
idresourcestrings.rstunneltransformerror='Transform failed'


# hash value = 79922404
idresourcestrings.rstunnelcrcfailed='CRC Failed'


# hash value = 79563287
idresourcestrings.rstunnelconnectmsg='Connecting'


# hash value = 174193460
idresourcestrings.rstunneldisconnectmsg='Disconnect'


# hash value = 78949986
idresourcestrings.rstunnelconnecttomasterfailed='Cannt connect to the Mas'+
'ter server'


# hash value = 42042999
idresourcestrings.rstunneldontallowconnections='Do not allow connctions n'+
'ow'


# hash value = 66037826
idresourcestrings.rstunnelmessagetypeerror='Message type recognition erro'+
'r'


# hash value = 99721940
idresourcestrings.rstunnelmessagehandlingerror='Message handling failed'


# hash value = 52381204
idresourcestrings.rstunnelmessageinterpreterror='Interpretation of messag'+
'e failed'


# hash value = 176976356
idresourcestrings.rstunnelmessagecustominterpreterror='Custom message int'+
'erpretation failed'


# hash value = 117771038
idresourcestrings.rssocksrequestfailed='Request rejected or failed.'


# hash value = 172632462
idresourcestrings.rssocksrequestserverfailed='Request rejected because SO'+
'CKS server cannot connect.'


# hash value = 151578382
idresourcestrings.rssocksrequestidentfailed='Request rejected because the'+
' client program and identd report different user-ids.'


# hash value = 67673566
idresourcestrings.rssocksunknownerror='Unknown socks error.'


# hash value = 211165054
idresourcestrings.rssocksserverresponderror='Socks server did not respond'+
'.'


# hash value = 234216398
idresourcestrings.rssocksauthmethoderror='Invalid socks authentication me'+
'thod.'


# hash value = 31848398
idresourcestrings.rssocksautherror='Authentication error to socks server.'+


# hash value = 236544638
idresourcestrings.rssocksservergeneralerror='General SOCKS server failure'+
'.'


# hash value = 178203198
idresourcestrings.rssocksserverpermissionerror='Connection not allowed by'+
' ruleset.'


# hash value = 50099358
idresourcestrings.rssocksservernetunreachableerror='Network unreachable.'


# hash value = 32338798
idresourcestrings.rssocksserverhostunreachableerror='Host unreachable.'


# hash value = 192796430
idresourcestrings.rssocksserverconnectionrefusederror='Connection refused'+
'.'


# hash value = 185101742
idresourcestrings.rssocksserverttlexpirederror='TTL expired.'


# hash value = 76465678
idresourcestrings.rssocksservercommanderror='Command not supported.'


# hash value = 42242750
idresourcestrings.rssocksserveraddresserror='Address type not supported.'


# hash value = 237990638
idresourcestrings.rsdestinationfilealreadyexists='Destination file alread'+
'y exists.'


# hash value = 136698878
idresourcestrings.rssslaccepterror='Error accepting connection with SSL.'


# hash value = 151912750
idresourcestrings.rssslconnecterror='Error connecting with SSL.'


# hash value = 206120878
idresourcestrings.rssslsettingciphererror='SetCipher failed.'


# hash value = 53726030
idresourcestrings.rssslcreatingcontexterror='Error creating SSL context.'


# hash value = 213581934
idresourcestrings.rssslloadingrootcerterror='Could not load root certific'+
'ate.'


# hash value = 3176686
idresourcestrings.rssslloadingcerterror='Could not load certificate.'


# hash value = 149363278
idresourcestrings.rssslloadingkeyerror='Could not load key, check passwor'+
'd.'


# hash value = 143110430
idresourcestrings.rssslgetmethoderror='Error geting SSL method.'


# hash value = 4733102
idresourcestrings.rsssldatabindingerror='Error binding data to SSL socket'+
'.'


# hash value = 148371246
idresourcestrings.rsmsgcmpedtrnew='&New Message Part...'


# hash value = 61729682
idresourcestrings.rsmsgcmpedtrextrahead='Extra Headers Text Editor'


# hash value = 266686898
idresourcestrings.rsmsgcmpedtrbodytext='Body Text Editor'


# hash value = 149787124
idresourcestrings.rsicmpnotenoughtbytes='Not enough bytes received'


# hash value = 80554724
idresourcestrings.rsicmpnonechoresponse='Non-echo type response received'


# hash value = 96951956
idresourcestrings.rsicmpwrongdestination='Received someone else'#39's pac'+
'ket'


# hash value = 4479524
idresourcestrings.rsnntpservernotrecognized='Command not recognized'


# hash value = 241543605
idresourcestrings.rsnntpservergoodbye='Goodbye'


# hash value = 230420273
idresourcestrings.rsgopherservernoprogramcode='Error: No program code to '+
'return request!'


# hash value = 146414094
idresourcestrings.rsinvalidsyslogpri='Invalid syslog message: incorrect P'+
'RI section'


# hash value = 169250658
idresourcestrings.rsinvalidsyslogprinumber='Invalid syslog message: incor'+
'rect PRI number "%s"'


# hash value = 130872514
idresourcestrings.rsinvalidsyslogtimestamp='Invalid syslog message: incor'+
'rect timestamp "%s"'


# hash value = 149226745
idresourcestrings.rsinvalidsyslogpacketsize='Invalid Syslog message: pack'+
'et too large (%d bytes)'


# hash value = 241626619
idresourcestrings.rsinvalidhostname='Invalid host name. A SYSLOG host nam'+
'e cannot contain any space ("%s")+'


# hash value = 668702
idresourcestrings.rsosslmodenotset='Mode has not been set.'


# hash value = 4851454
idresourcestrings.rsosslcouldnotloadssllibrary='Could not load SSL librar'+
'y.'


# hash value = 23937138
idresourcestrings.rsosslstatusstring='SSL status: "%s"'


# hash value = 206554350
idresourcestrings.rsosslconnectiondropped='SSL connection has dropped.'


# hash value = 181744078
idresourcestrings.rsosslcertificatelookup='SSL certificate request error.'+


# hash value = 183180814
idresourcestrings.rsosslinternal='SSL library internal error.'


# hash value = 58655323
idresourcestrings.rswsockstack='Winsock stack'


# hash value = 4342052
idresourcestrings.rssmtpsvrcmdnotrecognized='Command Not Recognised'


# hash value = 1100694
idresourcestrings.rssmtpsvrquit='Signing Off'


# hash value = 1371
idresourcestrings.rssmtpsvrok='Ok'


# hash value = 127229854
idresourcestrings.rssmtpsvrstartdata='Start mail input; end with <CRLF>.<'+
'CRLF>'


# hash value = 238015769
idresourcestrings.rssmtpsvraddressok='%s Address Okay'


# hash value = 48616066
idresourcestrings.rssmtpsvraddresserror='%s Address Error'


# hash value = 261892020
idresourcestrings.rssmtpsvraddresswillforward='User not local, Will forwa'+
'rd'


# hash value = 168281778
idresourcestrings.rssmtpsvrwelcome='Welcome to the INDY SMTP Server'


# hash value = 204674595
idresourcestrings.rssmtpsvrhello='Hello %s'


# hash value = 241483535
idresourcestrings.rssmtpsvrnohello='Polite people say HELO'


# hash value = 185819939
idresourcestrings.rssmtpsvrcmdgeneralerror='Syntax Error - Command not un'+
'derstood: %s'


# hash value = 248492370
idresourcestrings.rssmtpsvrxserver='Indy SMTP Server'


# hash value = 198754352
idresourcestrings.rssmtpsvrreceivedheader='by DNSName [127.0.0.1] running'+
' Indy SMTP'


# hash value = 127998596
idresourcestrings.rssmtpsvrauthfailed='Authentication Failed'


# hash value = 217420995
idresourcestrings.rspop3svrnothandled='Command Not Handled: %s'


# hash value = 29133502
idresourcestrings.rsunevensizeindecodestream='Uneven size in DecodeToStre'+
'am.'


# hash value = 150668526
idresourcestrings.rsunevensizeinencodestream='Uneven size in Encode.'


# hash value = 134822132
idresourcestrings.rsmessagedecodernotfound='Message decoder not found'


# hash value = 134981876
idresourcestrings.rsmessageencodernotfound='Message encoder not found'


# hash value = 13502254
idresourcestrings.rsmessagecodermimeunrecognizedcontenttrasnferencoding='U'+
'nrecognized content trasnfer encoding.'


# hash value = 217524526
idresourcestrings.rsunrecognizeduueencodingscheme='Unrecognized UUE encod'+
'ing scheme.'


# hash value = 124061550
idresourcestrings.rsipmcastinvalidmulticastaddress='The supplied IP addre'+
'ss is not a valid multicast address [224.0.0.0 to 239.255.255.255].'


# hash value = 259422734
idresourcestrings.rsipmcastnotsupportedonwin32='This function is not supp'+
'orted on Win32.'


# hash value = 84680990
idresourcestrings.rsftpdefaultgreeting='Indy FTP Server ready.'


# hash value = 117632782
idresourcestrings.rsftpopendataconn='Data connection already open; transf'+
'er starting.'


# hash value = 204941342
idresourcestrings.rsftpdataconntoopen='File status okay; about to open da'+
'ta connection.'


# hash value = 11637118
idresourcestrings.rsftpcmdsuccessful='%s Command successful.'


# hash value = 123780446
idresourcestrings.rsftpserviceopen='Service ready for new user.'


# hash value = 81130638
idresourcestrings.rsftpserverclosed='Service closing control connection.'


# hash value = 226542302
idresourcestrings.rsftpdataconn='Data connection open; no transfer in pro'+
'gress.'


# hash value = 150430702
idresourcestrings.rsftpdataconnclosed='Closing data connection.'


# hash value = 20375182
idresourcestrings.rsftpdataconnclosedabnormally='Data connection closed a'+
'bnormally.'


# hash value = 83862238
idresourcestrings.rsftppassivemode='Entering Passive Mode (%s).'


# hash value = 120406798
idresourcestrings.rsftpuserlogged='User logged in, proceed.'


# hash value = 187017758
idresourcestrings.rsftpanonymoususerlogged='Anonymous user logged in, pro'+
'ceed.'


# hash value = 205783726
idresourcestrings.rsftpfileactioncompleted='Requested file action okay, c'+
'ompleted.'


# hash value = 209579502
idresourcestrings.rsftpdirfilecreated='"%s" created.'


# hash value = 22759582
idresourcestrings.rsftpuserokay='User name okay, need password.'


# hash value = 75900862
idresourcestrings.rsftpanonymoususerokay='Anonymous login OK, send e-mail'+
' as password.'


# hash value = 212342126
idresourcestrings.rsftpneedloginwithuser='Login with USER first.'


# hash value = 108647854
idresourcestrings.rsftpneedaccountforlogin='Need account for login.'


# hash value = 92111470
idresourcestrings.rsftpfileactionpending='Requested file action pending f'+
'urther information.'


# hash value = 251627678
idresourcestrings.rsftpservicenotavailable='Service not available, closin'+
'g control connection.'


# hash value = 69218830
idresourcestrings.rsftpcantopendataconn='Can'#39't open data connection.'


# hash value = 19653230
idresourcestrings.rsftpfileactionnottaken='Requested file action not take'+
'n.'


# hash value = 123603918
idresourcestrings.rsftpfileactionaborted='Requested action aborted: local'+
' error in processing.'


# hash value = 192558846
idresourcestrings.rsftprequestedactionnottaken='Requested action not take'+
'n.'


# hash value = 212750654
idresourcestrings.rsftpcmdsyntaxerror='Syntax error, command unrecognized'+
'.'


# hash value = 99084750
idresourcestrings.rsftpcmdnotimplemented='"%s" Command not implemented.'


# hash value = 198271118
idresourcestrings.rsftpusernotloggedin='Not logged in.'


# hash value = 28134446
idresourcestrings.rsftpneedaccforfiles='Need account for storing files.'


# hash value = 192558846
idresourcestrings.rsftpactionnottaken='Requested action not taken.'


# hash value = 20162862
idresourcestrings.rsftpactionaborted='Requested action aborted: page type'+
' unknown.'


# hash value = 91170750
idresourcestrings.rsftprequestedfileactionaborted='Requested file action '+
'aborted.'


# hash value = 192558846
idresourcestrings.rsftprequestedfileactionnottaken='Requested action not '+
'taken.'


# hash value = 11834894
idresourcestrings.rsftpmaxconnections='Maximum connections limit exceeded'+
'. Try again later.'


# hash value = 78699214
idresourcestrings.rsftpcurrentdirectoryis='"%s" is working directory.'


# hash value = 31910974
idresourcestrings.rsftptypechanged='Type set to %s.'


# hash value = 233235566
idresourcestrings.rsftpmodechanged='Mode set to %s.'


# hash value = 73211486
idresourcestrings.rsftpstruchanged='Structure set to %s.'


# hash value = 241793893
idresourcestrings.rsftpsitecmdssupported='The following SITE commands are'+
' supported:'#13' HELP  DIRSTYLE'


# hash value = 45850174
idresourcestrings.rsftpdirectorystru='%s directory structure.'


# hash value = 166526467
idresourcestrings.rsftpcmdendofstat='End of Status'


# hash value = 126332286
idresourcestrings.rsftpcmdextssupported='Extensions supported:'#13#10'SIZ'+
'E'#13#10'PASV'#13#10'REST'#13#10'End of extentions.'


# hash value = 237157297
idresourcestrings.rsftpnoondirevent='No OnListDirectory event found!'


# hash value = 98755891
idresourcestrings.str_syslog_facility_kernel='kernel messages'


# hash value = 218025635
idresourcestrings.str_syslog_facility_user='user-level messages'


# hash value = 132371805
idresourcestrings.str_syslog_facility_mail='mail system'


# hash value = 181575299
idresourcestrings.str_syslog_facility_sys_daemon='system daemons'


# hash value = 162405401
idresourcestrings.str_syslog_facility_security1='security/authorization m'+
'essages (1)'


# hash value = 236959716
idresourcestrings.str_syslog_facility_internal='messages generated intern'+
'ally by syslogd'


# hash value = 69472285
idresourcestrings.str_syslog_facility_lpr='line printer subsystem'


# hash value = 188369917
idresourcestrings.str_syslog_facility_nntp='network news subsystem'


# hash value = 3331501
idresourcestrings.str_syslog_facility_uucp='UUCP subsystem'


# hash value = 193998793
idresourcestrings.str_syslog_facility_clock1='clock daemon (1)'


# hash value = 162405481
idresourcestrings.str_syslog_facility_security2='security/authorization m'+
'essages (2)'


# hash value = 111352702
idresourcestrings.str_syslog_facility_ftp='FTP daemon'


# hash value = 172150877
idresourcestrings.str_syslog_facility_ntp='NTP subsystem'


# hash value = 157862484
idresourcestrings.str_syslog_facility_audit='log audit'


# hash value = 157835204
idresourcestrings.str_syslog_facility_alert='log alert'


# hash value = 193998777
idresourcestrings.str_syslog_facility_clock2='clock daemon (2)'


# hash value = 219501081
idresourcestrings.str_syslog_facility_local0='local use 0  (local0)'


# hash value = 219435529
idresourcestrings.str_syslog_facility_local1='local use 1  (local1)'


# hash value = 219370105
idresourcestrings.str_syslog_facility_local2='local use 2  (local2)'


# hash value = 219304553
idresourcestrings.str_syslog_facility_local3='local use 3  (local3)'


# hash value = 219239001
idresourcestrings.str_syslog_facility_local4='local use 4  (local4)'


# hash value = 219173449
idresourcestrings.str_syslog_facility_local5='local use 5  (local5)'


# hash value = 220156601
idresourcestrings.str_syslog_facility_local6='local use 6  (local6)'


# hash value = 220091049
idresourcestrings.str_syslog_facility_local7='local use 7  (local7)'


# hash value = 134692517
idresourcestrings.str_syslog_facility_unknown='Unknown or illegale facili'+
'ty code'


# hash value = 52500085
idresourcestrings.str_syslog_severity_emergency='Emergency: system is unu'+
'sable'


# hash value = 253682185
idresourcestrings.str_syslog_severity_alert='Alert: action must be taken '+
'immediately'


# hash value = 159490883
idresourcestrings.str_syslog_severity_critical='Critical: critical condit'+
'ions'


# hash value = 180761827
idresourcestrings.str_syslog_severity_error='Error: error conditions'


# hash value = 18138067
idresourcestrings.str_syslog_severity_warning='Warning: warning condition'+
's'


# hash value = 241278958
idresourcestrings.str_syslog_severity_notice='Notice: normal but signific'+
'ant condition'


# hash value = 156818387
idresourcestrings.str_syslog_severity_informational='Informational: infor'+
'mational messages'


# hash value = 37989059
idresourcestrings.str_syslog_severity_debug='Debug: debug-level messages'


# hash value = 230954165
idresourcestrings.str_syslog_severity_unknown='Unknown or illegale securi'+
'ty code'


# hash value = 104212227
idresourcestrings.rslprerror='Reply %s on Job ID %s'


# hash value = 206722702
idresourcestrings.rslprunknown='Unknown'


# hash value = 108342388
idresourcestrings.rsirccannotconnect='IRC Connect Failed'


# hash value = 59523390
idresourcestrings.rsircnotconnected='Not connected to server.'


# hash value = 122334147
idresourcestrings.rsircclientversion='TIdIRC 1.061 by Steve Williams'


# hash value = 136598894
idresourcestrings.rsircclientinfo='%s Non-visual component for 32-bit Del'+
'phi.'


# hash value = 348059
idresourcestrings.rsircnick='Nick'


# hash value = 247929147
idresourcestrings.rsircaltnick='OtherNick'


# hash value = 164184565
idresourcestrings.rsircusername='username'


# hash value = 132587653
idresourcestrings.rsircrealname='Real name'


# hash value = 9619811
idresourcestrings.rsirctimeisnow='Local time is %s'


# hash value = 179730148
idresourcestrings.rshl7statusstopped='Stopped'


# hash value = 36561060
idresourcestrings.rshl7statusnotconnected='Not Connected'


# hash value = 61256515
idresourcestrings.rshl7statusfailedtostart='Failed to Start: %s'


# hash value = 164681171
idresourcestrings.rshl7statusfailedtostop='Failed to Stop: %s'


# hash value = 88858836
idresourcestrings.rshl7statusconnected='Connected'


# hash value = 79563287
idresourcestrings.rshl7statusconnecting='Connecting'


# hash value = 31117235
idresourcestrings.rshl7statusreconnect='Reconnect at %s: %s'


# hash value = 156184775
idresourcestrings.rshl7notwhileworking='You cannot set %s while the HL7 C'+
'omponent is working'


# hash value = 113662343
idresourcestrings.rshl7notworking='Attempt to %s while the HL7 Component '+
'is not working'


# hash value = 172745344
idresourcestrings.rshl7notfailedtostop='Interface is unusable due to fail'+
'ure to stop'


# hash value = 118327876
idresourcestrings.rshl7alreadystarted='Interface was already started'


# hash value = 118711876
idresourcestrings.rshl7alreadystopped='Interface was already stopped'


# hash value = 241047044
idresourcestrings.rshl7modenotset='Mode is not initialised'


# hash value = 123349156
idresourcestrings.rshl7noasynevent='Component is in Asynchronous mode but'+
' OnMessageArrive has not been hooked'


# hash value = 41528900
idresourcestrings.rshl7nosynevent='Component is in Synchronous mode but  '+
'OnMessageReceive has not been hooked'


# hash value = 97674500
idresourcestrings.rshl7invalidport='Assigned Port value %d is invalid'


# hash value = 124677566
idresourcestrings.rshl7impossiblemessage='A message has been received but'+
' the commication mode is unknown'


# hash value = 11710583
idresourcestrings.rshl7unexpectedmessage='Unexpected message arrived to a'+
'n interface that is not listening'


# hash value = 163848389
idresourcestrings.rshl7unknownmode='Unknown mode'


# hash value = 252310292
idresourcestrings.rshl7clientthreadnotstopped='Unable to stop client thre'+
'ad'


# hash value = 260894933
idresourcestrings.rshl7sendmessage='Send a message'


# hash value = 23855621
idresourcestrings.rshl7noconnectionfound='Server Connection not locatable'+
' when sending message'


# hash value = 132576274
idresourcestrings.rshl7waitforanswer='You cannot send a message while you'+
' are still waiting for an answer'


# hash value = 106040718
idresourcestrings.rsmfdivalidobjecttype='Unsupported object type. You can'+
' assign only one of the following types or thir descendants: TStrings, T'+
'Stream.'


# hash value = 253513929
idresourcestrings.rsurinoproto='Protocol field is empty'


# hash value = 92554809
idresourcestrings.rsurinohost='Host field is empty'


# hash value = 226691908
idresourcestrings.rsihtchainednotassigned='You must chain this component '+
'to another I/O Handler before using it'


# hash value = 253036046
idresourcestrings.rssnppnomultiline='TIdSNPP Mess command only supports s'+
'ingle line Messages.'


# hash value = 87482675
idresourcestrings.rsthreadterminateandwaitfor='Cannot call TerminateAndWa'+
'itFor on FreeAndTerminate threads'

