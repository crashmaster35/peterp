RotatedBitmap 
  RotateBitmap 
     librlshared

Ocorrencias de RotatedBitmap:

Unit rlreport.pas
procedure TRLCustomAngleLabel.InternalPaint;
procedure TRLCustomAngleLabel.InternalPrint;

Unit rlbarcode.pas
procedure TRLCustomBarcode.InternalPaint;
procedure TRLCustomBarcode.InternalPrint;


Ocorrencias de RotateBitmap:

Unit rlutils.pas
function RotatedBitmap(aSource:TBitmap; aAngle:double):TBitmap;


Ocorrencias de DoColorTable

Unit rldraftfilter.pas
procedure TRLDraftFilter.AddGraphic(aGraphic:TGraphic; const aRect:TRect; aList:TObjectList);


Ocorrencias de DoErrorDiffusion

Unit rldraftfilter.pas
procedure TRLDraftFilter.AddGraphic(aGraphic:TGraphic; const aRect:TRect; aList:TObjectList);


Ocorrencias de CanvasGetDescent

Unit rlrichparsers.pas

function TRLRichWord.NewPart(const Text:string):TRLRichWordPart;
